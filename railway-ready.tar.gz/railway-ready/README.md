# 🎮 OVERTAKE 스테이킹 모니터 봇

Sui 블록체인의 OVERTAKE (TAKE) 토큰 스테이킹을 실시간으로 모니터링하는 텔레그램 봇입니다.

---

## ✨ 주요 기능

### 📊 감지 가능한 활동

| 활동 | 아이콘 | 설명 |
|------|--------|------|
| **Deposit** | 🟢 | TAKE 토큰 스테이킹 |
| **Request Unstake** | 🟡 | 언스테이킹 요청 (7일 대기 시작) |
| **Claim Unstake** | 🔴 | 실제 인출 (7일 후) |

### 🔧 기타 기능

- ✅ 임계값 설정 (기본: $10,000 USD)
- ✅ 실시간 가격 조회
- ✅ 사용자별 독립 설정
- ✅ 자동 재시작 (Railway 배포 시)
- ✅ 다중 사용자 지원

---

## 🚀 설치 방법

### 1단계: 텔레그램 봇 생성

1. 텔레그램에서 **@BotFather** 검색
2. `/newbot` 입력
3. 봇 이름 설정 (예: OVERTAKE Monitor)
4. 봇 유저네임 설정 (예: overtake_monitor_bot)
5. **BOT_TOKEN** 복사 (예: `123456789:ABC...`)

### 2단계: 프로젝트 설치

```bash
# 프로젝트 폴더로 이동
cd /Users/myunggeunjung/overtake_staking_bot

# 의존성 설치
npm install
```

### 3단계: 환경변수 설정

```bash
# 방법 1: 직접 설정
export BOT_TOKEN="본인_텔레그램_봇_토큰"

# 방법 2: .env 파일 (선택)
cp .env.example .env
# .env 파일 열어서 BOT_TOKEN 수정
```

### 4단계: 실행

```bash
npm start
```

---

## 📖 사용 방법

### 기본 명령어

| 명령어 | 설명 |
|--------|------|
| `/start` | 환영 메시지 |
| `/help` | 도움말 |
| `/monitor` | 모니터링 시작 (기본값: $10,000) |
| `/stop` | 모니터링 중지 |
| `/status` | 현재 상태 확인 |

### 설정 명령어

| 명령어 | 예시 | 설명 |
|--------|------|------|
| `/threshold [금액]` | `/threshold 5000` | 임계값 변경 (USD) |
| `/price` | `/price` | 현재 TAKE 가격 조회 |

### 사용 예시

```
👤: /start
🤖: 환영합니다! /monitor로 시작하세요.

👤: /monitor
🤖: ✅ 모니터링이 시작되었습니다!
    💵 임계값: $10,000

[큰 스테이킹 발생 시]
🤖: 🟢 OVERTAKE 스테이킹
    💰 금액: 50,000 TAKE
    💵 USD: $14,000
    👤 주소: 0xc477...
    🔗 TX: View on Suiscan

👤: /threshold 5000
🤖: ✅ 임계값이 변경되었습니다!
    💵 새 임계값: $5,000

👤: /status
🤖: 📊 현재 상태
    🔔 모니터링: 🟢 활성
    💵 임계값: $5,000
    💰 TAKE 가격: $0.2800
```

---

## 🌐 Railway 배포 (24/7 실행)

### GitHub 업로드

```bash
cd /Users/myunggeunjung/overtake_staking_bot

# Git 초기화
git init
git add .
git commit -m "Initial commit"

# GitHub에서 New repository 생성 (overtake-staking-bot)

git remote add origin https://github.com/본인유저네임/overtake-staking-bot.git
git branch -M main
git push -u origin main
```

### Railway 배포

1. https://railway.app 접속
2. **GitHub으로 로그인**
3. **New Project** → **Deploy from GitHub repo**
4. **overtake-staking-bot** 선택
5. **Variables** 탭 → **New Variable**:
   - Name: `BOT_TOKEN`
   - Value: `본인_텔레그램_봇_토큰`
6. 자동 배포 시작! 🚀

### 배포 확인

- **Deployments** → 최신 배포 → **View Logs**
- "🤖 봇이 준비되었습니다!" 확인

### 코드 업데이트

```bash
git add .
git commit -m "설정 변경"
git push
```

→ Railway 자동 재배포

---

## 🔧 기술 스택

| 항목 | 사용 기술 |
|------|----------|
| **블록체인** | Sui Network |
| **SDK** | @mysten/sui.js |
| **봇 프레임워크** | node-telegram-bot-api |
| **가격 API** | CoinGecko |
| **저장소** | JSON 파일 (users.json) |

---

## 📊 스테이킹 컨트랙트 정보

```
Package: 0x2b5b2081ce2428bdd67057ed6d62d1112173ded3588eab63ab93c2042a0b296a
Module: staking

Functions:
- deposit           (스테이킹)
- request_unstake   (언스테이킹 요청)
- claim_unstake     (클레임)
```

```
TAKE Token: 0x76a49ebaf991fa2d4cb6a352af14425d453fe2ba6802b5ed2361b227150b6689::take::TAKE
```

---

## 🐛 트러블슈팅

### 로컬 실행

**"BOT_TOKEN 환경변수를 설정해주세요"**
```bash
export BOT_TOKEN="본인_토큰"
npm start
```

**"Polling error"**
- 토큰 확인
- 다른 곳에서 실행 중인지 확인 (로컬 + Railway 동시 불가)

### Railway

**배포 실패**
- Logs 확인
- Variables에 BOT_TOKEN 있는지 확인

**봇 무응답**
- Logs에서 "봇이 준비되었습니다" 확인
- 텔레그램에서 /start 먼저 보냈는지 확인

### Sui RPC 에러

**"Failed to fetch"**
- RPC 변경 (monitor.js 4번째 줄):
```javascript
const SUI_RPC = 'https://sui-mainnet.nodereal.io';
```

---

## ⚙️ 고급 설정

### 체크 간격 변경

`monitor.js` 271번째 줄:
```javascript
// 10초 → 5초로 변경
}, 5000);
```

### 기본 임계값 변경

`bot.js` 74번째 줄:
```javascript
threshold: 5000, // $10,000 → $5,000
```

---

## 📝 파일 구조

```
overtake-staking-bot/
├── bot.js           # 텔레그램 봇 메인
├── monitor.js       # Sui 블록체인 모니터링
├── database.js      # 사용자 설정 관리
├── price.js         # TAKE 가격 조회
├── package.json     # 의존성
├── users.json       # 사용자 데이터 (자동 생성)
├── .env.example     # 환경변수 예시
├── .gitignore       # Git 제외
└── README.md        # 이 파일
```

---

## 💰 비용

### Railway 무료 플랜

- 월 $5 크레딧
- 실행 시간: 500시간/월
- 메모리: 512MB
- **예상 사용량:** $1-2/월 (무료 범위)

---

## 🔐 보안

### .gitignore 포함

- `users.json` (사용자 데이터)
- `.env` (환경변수)
- `node_modules`

### 주의사항

- **BOT_TOKEN**은 환경변수로만 관리
- **users.json**은 Railway 서버에만 저장
- GitHub에 민감 정보 업로드 금지

---

## 🔧 문제 해결

### 자주 발생하는 에러

#### 1. `Unexpected status code: 502`

```
[6710244354] claim_unstake 조회 오류: Unexpected status code: 502
```

**원인**: Sui RPC 노드 일시적 과부하
**해결**: 자동 재시도 (최대 3번) - 정상 작동
**조치**: 대부분 다음 체크에서 정상화됨

---

#### 2. `Too Many Requests: 429`

```
텔레그램 전송 실패: ETELEGRAM: 429 Too Many Requests
```

**원인**: Telegram API Rate Limit 초과
**해결**: 자동 재시도 (Retry-After 대기)
**예방**: CoinGecko API 캐싱 (30초)

---

#### 3. 같은 트랜잭션 중복 알림

**원인**: `processedSet`에 기록 실패
**해결**: v1.1.0부터 수정 완료
**조치**: 최신 버전 사용

---

#### 4. 금액 추출 실패

```
[6710244354] ⚠️ 금액 추출 실패 - amount = 0
```

**원인**: 이벤트 구조 변경 또는 새로운 필드명
**해결**: extractTakeAmount() 함수 업데이트 필요
**조치**: 로그 확인 후 제보

---

### 일반적인 문제

#### 봇이 응답 안 함
```bash
# 봇 프로세스 확인
ps aux | grep node

# 재시작
npm start
```

#### 알림이 안 옴
```bash
# 텔레그램에서
/status  # 현재 상태 확인
/stop
/monitor  # 재시작
```

#### Railway 배포 실패
```bash
# 로그 확인
railway logs

# 환경변수 확인
railway variables
```

---

## ❓ FAQ

**Q: 여러 명이 동시에 사용 가능?**
→ ✅ 네, 각자 독립적 설정

**Q: 재시작 시 설정 사라짐?**
→ ❌ users.json에 저장되어 자동 복구

**Q: Railway 완전 무료?**
→ ⚠️ 월 $5 크레딧, 이 봇은 $1-2/월 사용

**Q: GitHub 안전?**
→ ✅ .gitignore로 민감 정보 제외

**Q: 로컬 + Railway 동시 실행?**
→ ❌ 텔레그램은 한 곳에서만 가능

**Q: 스테이킹 외 다른 활동도 감지?**
→ ✅ Deposit, Request Unstake, Claim Unstake 모두 감지

**Q: 가격이 안 맞아요**
→ CoinGecko API 기준 (실시간 반영)

**Q: 502 에러가 계속 나요**
→ ✅ 자동 재시도 (3번) - 보통 2-3번째에 성공

---

## 📞 문의

문제가 있으면 로그를 확인하고, 에러 메시지와 함께 문의하세요.

---

**⚡ Happy Monitoring! ⚡**

---

## 📚 참고 링크

- [Sui 공식 문서](https://docs.sui.io/)
- [OVERTAKE 스테이킹](https://staking.overtake.market/)
- [Suiscan Explorer](https://suiscan.xyz/)
- [Railway 문서](https://docs.railway.app/)
